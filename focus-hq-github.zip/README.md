# FOCUS HQ

A mobile-friendly study tracker for A/L Maths, Physics and ICT with a focus timer, Instagram usage logging, seven-day challenge and local progress dashboard.

## Publish with GitHub Pages

1. Create a new **public** GitHub repository named `focus-hq`.
2. Upload **all files and the `assets` folder** from this project to the root of the repository. Make sure `index.html` is at the root.
3. In the repository, open **Settings → Pages**.
4. Set **Source: Deploy from a branch**, **Branch: main**, **Folder: /(root)**, and save.
5. Once published, visit `https://YOUR-USERNAME.github.io/focus-hq/`.

## Install on phone

Open the published site in a compatible mobile browser and use **Add to Home screen** or **Install app** if offered. Installability depends on browser support.

## Privacy and data

Progress is stored in your browser's localStorage. There is no account, server or cross-device synchronization. Clearing browser data may delete progress. Use the app's export/import backup feature before changing devices. Instagram time is entered manually; this app cannot block other apps or read phone screen-time statistics.

## Local development

For full PWA features, serve the folder over localhost, e.g. `python -m http.server 8000`, then open `http://localhost:8000`. The HTML can also be opened directly, but service workers require HTTPS or localhost.
